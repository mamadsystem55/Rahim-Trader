[app]
title = Rahim Trader
package.name = rahimtrader
package.domain = org.rahimtrader
source.dir = .
source.include_exts = py,kv,png,jpg,atlas,json
version = 0.1
requirements = python3,kivy==2.3.1
orientation = portrait
fullscreen = 0

[android]

android.permissions = INTERNET
android.api = 35
android.minapi = 23
android.archs = arm64-v8a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
