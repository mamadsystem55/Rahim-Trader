from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.network.urlrequest import UrlRequest
import json

KV = """
<RahimRoot>:
    orientation: "vertical"
    padding: "16dp"
    spacing: "12dp"
    canvas.before:
        Color:
            rgba: 0.055, 0.075, 0.12, 1
        Rectangle:
            pos: self.pos
            size: self.size
    Label:
        text: "[b]RAHIM TRADER[/b]"
        markup: True
        font_size: "25sp"
        size_hint_y: None
        height: "54dp"
        color: 0.35, 0.85, 0.75, 1
    Label:
        text: "نسخه آزمایشی | فقط رصد بازار"
        font_size: "16sp"
        size_hint_y: None
        height: "32dp"
        color: 0.9, 0.92, 0.96, 1
    Label:
        text: root.status
        font_size: "14sp"
        size_hint_y: None
        height: "54dp"
        color: 1, 0.82, 0.35, 1
    Button:
        text: "بررسی اتصال به بیت‌پین"
        size_hint_y: None
        height: "52dp"
        on_release: root.check_connection()
    Label:
        text: root.result
        font_size: "14sp"
        color: 0.9, 0.92, 0.96, 1
        halign: "center"
        valign: "middle"
        text_size: self.width, None
    Widget:
    Label:
        text: "معامله واقعی غیرفعال است. این نسخه سفارش ثبت نمی‌کند."
        font_size: "12sp"
        size_hint_y: None
        height: "42dp"
        color: 0.75, 0.78, 0.84, 1
"""

class RahimRoot(BoxLayout):
    status = StringProperty("آماده")
    result = StringProperty("برای آزمایش ارتباط اینترنتی دکمه بالا را بزن.")

    def check_connection(self):
        self.status = "در حال بررسی ارتباط..."
        self.result = ""
        UrlRequest(
            "https://api.bitpin.ir/",
            on_success=self._success,
            on_failure=self._failure,
            on_error=self._error,
            timeout=15
        )

    def _success(self, req, result):
        self.status = "اتصال اینترنت برقرار است"
        self.result = "پاسخ از سرور دریافت شد. مرحله بعد: اتصال امن به داده‌های بازار."

    def _failure(self, req, result):
        self.status = "سرور پاسخ نداد"
        self.result = "اتصال برقرار نشد؛ اینترنت یا نشانی سرویس را بررسی کن."

    def _error(self, req, error):
        self.status = "خطا در ارتباط"
        self.result = str(error)

class RahimTraderApp(App):
    def build(self):
        Builder.load_string(KV)
        return RahimRoot()

if __name__ == "__main__":
    RahimTraderApp().run()
